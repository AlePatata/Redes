# ## Pruebas paralelas en LOCALHOST
Tamaño de buffer: 4096 bytes
**Tiempo total (100 clientes)**: 4.7221 segundos
-------------------------
Tamaño de buffer: 32768 bytes
**Tiempo total (100 clientes)**: 4.6507 segundos
-------------------------
# ## Pruebas paralelas en ANAKENA
Tamaño de buffer: 4096 bytes
**Tiempo total (100 clientes)**: 5.5924 segundos
-------------------------
Tamaño de buffer: 32768 bytes
**Tiempo total (100 clientes)**: 5.1807 segundos
-------------------------
